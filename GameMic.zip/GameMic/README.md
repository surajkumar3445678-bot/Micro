# Game Mic (GG Game Space-style floating microphone)
Open this folder in Android Studio (Hedgehog+), let it sync (it creates the Gradle wrapper), then Build > Build APK(s).
1. Launch app, tap "Start floating mic", grant Microphone, Notifications, Display-over-other-apps.
2. Bubble floats over any app/game: drag to move, tap to expand. Notification has Show/Hide and Stop.
## Audio routing limits (honest)
- Android does not allow an app to replace another app's mic input. Processed audio CANNOT be injected into game voice chat without root (virtual-mic Magisk/audio HAL module) or system privileges.
- Android 10+: only the foreground app (the game) is guaranteed mic data; a background foreground-service may get silence while the game records.
- Implemented alternatives: headphone monitoring; "Speaker bridge" (processed voice from speaker, picked up acoustically by the game mic; use with echo caution); best-effort system mic mute.
- Android 14: start the service while the app is visible (the Start button does this).
