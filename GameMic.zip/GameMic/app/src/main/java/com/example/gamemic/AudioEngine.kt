package com.example.gamemic
import android.content.Context
import android.media.*
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import kotlin.math.*

/** Delay-line pitch shifter (two Hann-crossfaded taps). ratio<1 = deeper, >1 = higher. */
class PitchShifter {
    private val n = 4096; private val buf = FloatArray(n); private var w = 0
    private var phase = 0f; private val win = 1200f
    var ratio = 1f
    private fun tap(p: Float): Float {
        var r = w - p * win; if (r < 0) r += n
        val i = r.toInt(); val f = r - i
        val a = buf[i % n]; val b = buf[(i + 1) % n]
        return (a + (b - a) * f) * (0.5f - 0.5f * cos(2 * PI.toFloat() * p))
    }
    fun process(x: Float): Float {
        buf[w] = x
        phase += (1f - ratio) / win
        if (phase >= 1f) phase -= 1f; if (phase < 0f) phase += 1f
        val y = tap(phase) + tap((phase + 0.5f) % 1f)
        w = (w + 1) % n
        return y
    }
}

class AudioEngine(private val ctx: Context, private val onLevel: (Float) -> Unit) {
    companion object {
        const val RATE = 48000
        val EFFECTS = arrayOf("Normal", "Robot", "Deep", "Chipmunk", "Echo")
    }
    @Volatile var muted = false
    @Volatile var volume = 1f
    @Volatile var sensitivity = 0.5f
    @Volatile var effect = 0
    @Volatile var noiseSuppress = true
    @Volatile var monitor = false      // hear yourself in headphones
    @Volatile var bridge = false       // play processed voice out of the speaker (acoustic bridge to game mic)
    @Volatile private var running = false
    private var thread: Thread? = null
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun start() {
        if (running) return
        running = true
        thread = Thread({ loop() }, "gm-audio").also { it.priority = Thread.MAX_PRIORITY; it.start() }
    }
    fun stop() { running = false; thread?.join(800); thread = null }

    private fun device(bridge: Boolean): AudioDeviceInfo? {
        val d = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        val phones = setOf(AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET,
            AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_BLUETOOTH_A2DP)
        return if (bridge) d.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
        else d.firstOrNull { it.type in phones }
    }

    private fun makeTrack(bridge: Boolean): AudioTrack {
        val min = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(RATE).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .setBufferSizeInBytes(max(min, 960 * 2)).build()
        device(bridge)?.let { t.setPreferredDevice(it) }
        t.play(); return t
    }

    private fun loop() {
        val frame = 480 // 10 ms
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = try {
            AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, RATE, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, max(min, frame * 4))
        } catch (e: Exception) { running = false; return }
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); running = false; return }
        val ns = if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(rec.audioSessionId) else null
        val aec = if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(rec.audioSessionId) else null
        aec?.enabled = true
        rec.startRecording()

        val pcm = ShortArray(frame); val x = FloatArray(frame)
        var track: AudioTrack? = null; var trackBridge = false
        var hpX = 0f; var hpY = 0f; var gate = 0f; var hold = 0
        var rPhase = 0f
        val shifter = PitchShifter()
        val echo = FloatArray(RATE / 4); var ep = 0
        var lastEffect = -1

        while (running) {
            val n = rec.read(pcm, 0, frame)
            if (n <= 0) continue
            ns?.enabled = noiseSuppress
            // pass 1: DC/rumble high-pass + RMS
            var sum = 0f
            for (i in 0 until n) {
                val s = pcm[i] / 32768f
                val y = s - hpX + 0.995f * hpY; hpX = s; hpY = y
                x[i] = y; sum += y * y
            }
            val rms = sqrt(sum / n)
            onLevel(if (muted) 0f else min(1f, sqrt(rms * 12f)))
            // noise gate driven by sensitivity (higher = picks up quieter sounds)
            val sens = sensitivity
            val thr = 0.001f + 0.039f * (1f - sens) * (1f - sens)
            if (rms > thr) hold = 15 else if (hold > 0) hold--
            val target = if (hold > 0) 1f else 0f
            val eff = effect
            if (eff != lastEffect) { lastEffect = eff; shifter.ratio = if (eff == 2) 0.75f else 1.4f; echo.fill(0f) }
            val vol = volume
            for (i in 0 until n) {
                gate += (target - gate) * (if (target > gate) 0.02f else 0.002f)
                var v = x[i] * gate
                v = when (eff) {
                    1 -> { rPhase += 2f * PI.toFloat() * 70f / RATE; if (rPhase > 6.2831853f) rPhase -= 6.2831853f
                        v * 0.3f + 1.2f * v * sin(rPhase) }
                    2, 3 -> shifter.process(v)
                    4 -> { val d = echo[ep]; val o = v + d * 0.4f; echo[ep] = o * 0.9f; ep = (ep + 1) % echo.size; o }
                    else -> v
                }
                v *= vol
                pcm[i] = (v.coerceIn(-1f, 1f) * 32767f).toInt().toShort()
            }
            val want = (monitor || bridge) && !muted
            if (want) {
                if (track != null && trackBridge != bridge) { track.release(); track = null }
                if (track == null) { track = makeTrack(bridge); trackBridge = bridge }
                track.write(pcm, 0, n)
            } else if (track != null) { track.release(); track = null }
        }
        track?.release(); ns?.release(); aec?.release()
        try { rec.stop() } catch (_: Exception) {}
        rec.release()
        onLevel(0f)
    }
}
