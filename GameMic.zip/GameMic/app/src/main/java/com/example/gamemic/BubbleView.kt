package com.example.gamemic
import android.content.Context
import android.graphics.*
import android.view.View

class BubbleView(c: Context) : View(c) {
    var level = 0f; set(v) { field = v; invalidate() }
    var on = true; var muted = false
    private var sm = 0f
    private val dp = c.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onMeasure(w: Int, h: Int) { val s = (76 * dp).toInt(); setMeasuredDimension(s, s) }
    override fun onDraw(cv: Canvas) {
        sm += (level - sm) * 0.45f
        val cx = width / 2f; val cy = height / 2f; val base = 22 * dp
        val col = when { !on -> Color.rgb(107, 114, 128); muted -> Color.rgb(239, 68, 68); else -> Color.rgb(34, 197, 94) }
        if (on && !muted && sm > 0.02f) {          // activity animation: pulsing rings
            p.style = Paint.Style.FILL; p.color = Color.argb(70, Color.red(col), Color.green(col), Color.blue(col))
            cv.drawCircle(cx, cy, base + sm * 15 * dp, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 2 * dp
            p.color = Color.argb(150, Color.red(col), Color.green(col), Color.blue(col))
            cv.drawCircle(cx, cy, base + sm * 9 * dp, p)
        }
        p.style = Paint.Style.FILL; p.color = Color.argb(230, 17, 24, 39); cv.drawCircle(cx, cy, base, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 3 * dp; p.color = col; cv.drawCircle(cx, cy, base, p)
        p.color = Color.WHITE; p.strokeWidth = 2 * dp; p.strokeCap = Paint.Cap.ROUND
        p.style = Paint.Style.FILL
        cv.drawRoundRect(RectF(cx - 4.5f * dp, cy - 11 * dp, cx + 4.5f * dp, cy + 3 * dp), 4.5f * dp, 4.5f * dp, p)
        p.style = Paint.Style.STROKE
        cv.drawArc(RectF(cx - 8.5f * dp, cy - 7 * dp, cx + 8.5f * dp, cy + 8 * dp), 0f, 180f, false, p)
        cv.drawLine(cx, cy + 8 * dp, cx, cy + 12 * dp, p)
        if (!on || muted) { p.color = Color.rgb(239, 68, 68); p.strokeWidth = 3 * dp
            cv.drawLine(cx - 11 * dp, cy - 11 * dp, cx + 11 * dp, cy + 11 * dp, p) }
        if (sm > 0.01f) postInvalidateOnAnimation()
    }
}
