package com.example.gamemic
import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var startBtn: Button
    private lateinit var level: ProgressBar
    private val dp get() = resources.displayMetrics.density

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val s = Prefs.sp(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL
            setPadding((18 * dp).toInt(), (28 * dp).toInt(), (18 * dp).toInt(), (18 * dp).toInt()) }
        fun tv(t: String, size: Float = 14f) = TextView(this).apply { text = t; textSize = size; setTextColor(Color.WHITE) }
        col.addView(tv("Game Mic", 26f)); status = tv(""); col.addView(status)
        startBtn = Button(this).apply { setOnClickListener { toggle() } }; col.addView(startBtn)
        col.addView(tv("Live level")); level = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        col.addView(level)
        fun seek(label: String, key: String, max: Int, def: Int) {
            col.addView(tv(label))
            col.addView(SeekBar(this).apply { this.max = max; progress = s.getInt(key, def)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) { if (u) s.edit().putInt(key, p).apply() }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {} }) })
        }
        seek("Volume", "volume", 200, 100); seek("Sensitivity", "sens", 50.let { 100 }, 50)
        val fx = Button(this).apply { fun u() { text = "Voice effect: " + AudioEngine.EFFECTS[s.getInt("effect", 0)] }
            u(); setOnClickListener { s.edit().putInt("effect", (s.getInt("effect", 0) + 1) % AudioEngine.EFFECTS.size).apply(); u() } }
        col.addView(fx)
        fun cb(t: String, k: String, d: Boolean) = col.addView(CheckBox(this).apply { text = t; setTextColor(Color.WHITE)
            isChecked = s.getBoolean(k, d); setOnCheckedChangeListener { _, c -> s.edit().putBoolean(k, c).apply() } })
        cb("Noise suppression", "ns", true)
        cb("Monitor my voice (headphones only, avoids feedback)", "monitor", false)
        cb("Speaker bridge: play processed voice from speaker so the game mic hears it", "bridge", false)
        col.addView(tv("\nLimits: Android does not let one app replace another app's microphone input. " +
            "This app captures and processes your mic, shows the floating controls over games, and can route the " +
            "result to headphones or acoustically via speaker. Games may still receive the raw mic or silence " +
            "(Android 10+ gives the mic to the foreground app). True injection needs root/virtual-mic modules.", 12f))
        setContentView(ScrollView(this).apply { addView(col) })
        poll()
    }

    private fun toggle() {
        if (MicService.running) { stopService(Intent(this, MicService::class.java)); return }
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) { requestPermissions(need.toTypedArray(), 1); return }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow 'Display over other apps', then tap Start again", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return
        }
        startForegroundService(Intent(this, MicService::class.java))
    }

    private fun poll() {
        val r = MicService.running
        startBtn.text = if (r) "Stop floating mic" else "Start floating mic"
        status.text = if (r) "Running - floating mic is on screen" else "Stopped"
        level.progress = (MicService.lastLevel * 100).toInt()
        h.postDelayed({ poll() }, 60)
    }
    override fun onDestroy() { h.removeCallbacksAndMessages(null); super.onDestroy() }
}
