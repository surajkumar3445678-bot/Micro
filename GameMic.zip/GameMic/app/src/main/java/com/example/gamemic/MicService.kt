package com.example.gamemic
import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.*
import android.view.*
import android.widget.*

class MicService : Service() {
    companion object {
        const val ACT_STOP = "gm.stop"; const val ACT_HIDE = "gm.hide"
        @Volatile var running = false
        @Volatile var lastLevel = 0f
    }
    private lateinit var wm: WindowManager
    private lateinit var engine: AudioEngine
    private lateinit var root: LinearLayout
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var bubble: BubbleView
    private lateinit var panel: LinearLayout
    private lateinit var bar: ProgressBar
    private lateinit var btnOn: Button; private lateinit var btnMute: Button; private lateinit var btnFx: Button
    private lateinit var sbVol: SeekBar; private lateinit var sbSens: SeekBar
    private lateinit var cbNs: CheckBox; private lateinit var cbMon: CheckBox; private lateinit var cbBr: CheckBox
    private val h = Handler(Looper.getMainLooper())
    private var lastPost = 0L
    private var hidden = false
    private var sysMuteSet = false
    private val dp get() = resources.displayMetrics.density
    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> sync() }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        engine = AudioEngine(this) { l ->
            lastLevel = l
            val now = SystemClock.uptimeMillis()
            if (now - lastPost > 30) { lastPost = now; h.post { bubble.level = l; bar.progress = (l * 100).toInt() } }
        }
        buildOverlay()
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(listener)
        sync()
    }

    private fun sync() {
        val s = Prefs.sp(this)
        Prefs.applyTo(this, engine)
        val on = s.getBoolean("on", true); val muted = s.getBoolean("muted", false)
        if (on) engine.start() else engine.stop()
        // best effort: system-wide mic mute (OEM dependent)
        try { val am = getSystemService(AUDIO_SERVICE) as AudioManager
            if (muted != am.isMicrophoneMute) { am.isMicrophoneMute = muted; sysMuteSet = muted } } catch (_: Exception) {}
        bubble.on = on; bubble.muted = muted; bubble.invalidate()
        btnOn.text = if (on) "MIC ON" else "MIC OFF"
        btnMute.text = if (muted) "UNMUTE" else "MUTE"
        btnFx.text = "Voice: " + AudioEngine.EFFECTS[s.getInt("effect", 0)]
        if (!sbVol.isPressed) sbVol.progress = s.getInt("volume", 100)
        if (!sbSens.isPressed) sbSens.progress = s.getInt("sens", 50)
        cbNs.isChecked = s.getBoolean("ns", true); cbMon.isChecked = s.getBoolean("monitor", false)
        cbBr.isChecked = s.getBoolean("bridge", false)
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("gm", "Game Mic", NotificationManager.IMPORTANCE_LOW))
        fun pi(a: String, c: Int) = PendingIntent.getService(this, c, Intent(this, MicService::class.java).setAction(a),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, "gm").setContentTitle("Game Mic is running")
            .setContentText("Floating mic active").setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open).setOngoing(true)
            .addAction(android.R.drawable.ic_menu_view, "Show/Hide", pi(ACT_HIDE, 1))
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", pi(ACT_STOP, 2)).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) {
            ACT_STOP -> stopSelf()
            ACT_HIDE -> { hidden = !hidden; root.visibility = if (hidden) View.GONE else View.VISIBLE }
        }
        return START_NOT_STICKY
    }

    private fun txt(t: String) = TextView(this).apply { text = t; setTextColor(Color.WHITE); textSize = 12f }
    private fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; textSize = 11f; isAllCaps = false
        minHeight = 0; minimumHeight = (36 * dp).toInt(); setOnClickListener { a() } }
    private fun edit(k: String, v: Boolean) = Prefs.sp(this).edit().putBoolean(k, v).apply()
    private fun seek(key: String, max: Int) = SeekBar(this).apply { this.max = max
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) Prefs.sp(this@MicService).edit().putInt(key, p).apply() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {} }) }
    private fun check(t: String, k: String) = CheckBox(this).apply { text = t; setTextColor(Color.WHITE); textSize = 12f
        setOnCheckedChangeListener { v, c -> if (v.isPressed) edit(k, c) } }

    private fun buildOverlay() {
        val s = Prefs.sp(this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        bubble = BubbleView(this)
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            setPadding((12 * dp).toInt(), (10 * dp).toInt(), (12 * dp).toInt(), (10 * dp).toInt())
            background = GradientDrawable().apply { setColor(Color.argb(215, 12, 16, 22)); cornerRadius = 16 * dp }
        }
        btnOn = btn("MIC ON") { edit("on", !s.getBoolean("on", true)) }
        btnMute = btn("MUTE") { edit("muted", !s.getBoolean("muted", false)) }
        btnFx = btn("Voice") { Prefs.sp(this).edit().putInt("effect", (s.getInt("effect", 0) + 1) % AudioEngine.EFFECTS.size).apply() }
        sbVol = seek("volume", 200); sbSens = seek("sens", 100)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        cbNs = check("Noise suppression", "ns"); cbMon = check("Monitor (use headphones)", "monitor")
        cbBr = check("Speaker bridge (to game mic)", "bridge")
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(btnOn, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(btnMute, LinearLayout.LayoutParams(0, -2, 1f))
        panel.addView(txt("GAME MIC").apply { setTypeface(null, Typeface.BOLD) })
        panel.addView(bar); panel.addView(row); panel.addView(btnFx)
        panel.addView(txt("Volume")); panel.addView(sbVol)
        panel.addView(txt("Sensitivity")); panel.addView(sbSens)
        panel.addView(cbNs); panel.addView(cbMon); panel.addView(cbBr)
        panel.addView(btn("Hide (restore from notification)") { hidden = true; root.visibility = View.GONE })
        root.addView(bubble); root.addView(panel, LinearLayout.LayoutParams((250 * dp).toInt(), -2))
        lp = WindowManager.LayoutParams(-2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 300 }
        // drag anywhere, tap to expand/collapse
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        bubble.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val mx = e.rawX - dx; val my = e.rawY - dy
                    if (Math.abs(mx) > 8 * dp || Math.abs(my) > 8 * dp) moved = true
                    if (moved) { lp.x = (sx + mx).toInt(); lp.y = (sy + my).toInt(); wm.updateViewLayout(root, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) {
                    panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                    root.post { val sh = resources.displayMetrics.heightPixels
                        if (lp.y + root.height > sh) { lp.y = maxOf(0, sh - root.height); wm.updateViewLayout(root, lp) } }
                }
            }
            true
        }
        wm.addView(root, lp)
    }

    override fun onDestroy() {
        running = false; lastLevel = 0f
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(listener)
        engine.stop()
        try { if (sysMuteSet) (getSystemService(AUDIO_SERVICE) as AudioManager).isMicrophoneMute = false } catch (_: Exception) {}
        try { wm.removeView(root) } catch (_: Exception) {}
        super.onDestroy()
    }
}
