package com.example.gamemic
import android.content.Context
import android.content.SharedPreferences

/** Single source of truth shared by dashboard, overlay panel and engine. */
object Prefs {
    fun sp(c: Context): SharedPreferences = c.getSharedPreferences("gm", Context.MODE_PRIVATE)
    fun applyTo(c: Context, e: AudioEngine) {
        val s = sp(c)
        e.muted = s.getBoolean("muted", false)
        e.volume = s.getInt("volume", 100) / 100f
        e.sensitivity = s.getInt("sens", 50) / 100f
        e.effect = s.getInt("effect", 0)
        e.noiseSuppress = s.getBoolean("ns", true)
        e.monitor = s.getBoolean("monitor", false)
        e.bridge = s.getBoolean("bridge", false)
    }
}
